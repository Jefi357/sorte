<aside class="left-sidebar" data-sidebarbg="skin5">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
      <!-- Sidebar navigation-->
      <nav class="sidebar-nav">
        <ul id="sidebarnav" class="pt-4">
          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="../"
              aria-expanded="false"
              ><i class="mdi mdi-view-dashboard"></i
              ><span class="hide-menu">Página inicial</span></a
            >
          </li>
          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="../GGR"
              aria-expanded="false"
              ><i class="mdi mdi-margin"></i
              ><span class="hide-menu">GGR</span></a
            >
          </li>
          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="../usuarios"
              aria-expanded="false"
              ><i class="mdi mdi-account"></i
              ><span class="hide-menu">Usuários</span></a
            >
          </li>
          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="../depositos"
              aria-expanded="false"
              ><i class="mdi mdi-cash"></i
              ><span class="hide-menu">Depositos</span></a
            >
          </li>
          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="../saques"
              aria-expanded="false"
              ><i class="mdi mdi-cash"></i
              ><span class="hide-menu">Saques</span></a
            >
          </li>
          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="../saques-afiliados"
              aria-expanded="false"
              ><i class="mdi mdi-cash"></i
              ><span class="hide-menu">Saques Afiliados</span></a
            >
          </li>
          
           <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="../pixels"
              aria-expanded="false"
              ><i class="mdi mdi-code-tags"></i
              ><span class="hide-menu">Pixels</span></a
            >
          </li>
          
          
                    <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="../gateway"
              aria-expanded="false"
              ><i class="mdi mdi-cash"></i
              ><span class="hide-menu">Gateway</span></a
            >
          </li>
          
                    <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="../config"
              aria-expanded="false"
              ><i class="mdi mdi-account"></i
              ><span class="hide-menu">Configurações</span></a
            >
          </li>
          
           <li class="sidebar-item">
                            <a
                              class="sidebar-link waves-effect waves-dark sidebar-link"
                              href="../planos"
                              aria-expanded="false"
                              ><i class="mdi mdi-square-inc-cash"></i
                              ><span class="hide-menu">Afiliados</span></a
                            >
                        </li>
        
        
            <li class="sidebar-item p-3">
            <a
              href="https://t.me/+KuEkcLNK3yJkNWEx"
              target="_blank"
              class="
                w-100
                btn btn-cyan
                d-flex
                align-items-center
                text-white
              "
              ><i class="mdi mdi-message font-20 me-2"></i>Suporte</a
            >
          </li>
        </ul>
      </nav>
      <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
 </aside>